<?php

declare(strict_types=1);

namespace Small\Utils\Contract;

interface Arrayable
{
    public function toArray(): array;
}
