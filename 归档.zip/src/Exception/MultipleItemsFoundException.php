<?php

declare(strict_types=1);

namespace Small\Utils\Exception;

use RuntimeException;

class MultipleItemsFoundException extends RuntimeException
{
}
