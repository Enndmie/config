<?php

declare(strict_types=1);

namespace Small\Utils\Exception;

use Exception;

class FileNotFoundException extends Exception
{
}
